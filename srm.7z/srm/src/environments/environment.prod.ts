export const environment = {
  production: true,
  qa:false,
  dev: false,
  baseURL: 'http://localhost:8080'
};

export const environment = {
  production: false,
  qa:true,
  dev: false,
  baseURL: 'http://localhost:8080'
};

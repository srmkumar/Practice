import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { GenerateFields } from './generatercv/GenerateFields';
import { Rollbackfields } from './rollbackdev/Rollbackfields';

@Injectable({
  providedIn: 'root'
})
export class MainService {
  restAPI = environment.baseURL;
  isDev: boolean = false;
  isQA: boolean = false;
  constructor(public httpClient: HttpClient) { 
    if(environment.dev) {
      this.isDev = true;
    } else if(environment.qa){
      this.isQA = true;
    }
  }

  getStepSetData() {
    return this.httpClient.get(this.restAPI + '/api/astep')
  }

  generateRCV(fields: GenerateFields) {
    return this.httpClient.post(this.restAPI + '/api/generatercvsp', fields)
  }

  executeCatAgent() {
    return this.httpClient.get(this.restAPI + '/api/runcatagent', {responseType: 'text'});
  }

  getLetterKeys() {
    return this.httpClient.get(this.restAPI + '/api/getletterauditlevel');
  }

  getTasks(cdkValue: any) {
    return this.httpClient.post(this.restAPI + '/api/gettasks', cdkValue);
  }

  wipeOut(txStramKey: any) {
    return this.httpClient.post(this.restAPI + '/api/wipeout', txStramKey);
  }

  rollBackClaim(fields: Rollbackfields) {
    return this.httpClient.post(this.restAPI + '/api/rollback', fields)
  }

}

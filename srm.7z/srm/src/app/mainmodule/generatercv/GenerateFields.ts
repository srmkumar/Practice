export class GenerateFields {
    cdkValue: any = '';
    selectedLetterKey: any = '?';
    selectedAuditLevel: any = '?';
    selectedScanPrintCode: any = '?';
}

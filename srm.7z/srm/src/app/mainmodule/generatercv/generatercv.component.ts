import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { GenerateFields } from './GenerateFields';

@Component({
  selector: 'app-generatercv',
  templateUrl: './generatercv.component.html',
  styleUrls: ['./generatercv.component.css']
})
export class GeneratercvComponent implements OnInit {

  data: any;
  btnText = 'Generate RCV';
  runBtnText = 'Run CATAgent';
  error = false;
  success = false;
  errorMessage = '';
  successMessage = '';
  runningCAT: boolean = false;
  letterKeyData: any;
  constructor(private mainService: MainService, 
    public fields: GenerateFields) { }

  generateRCV() {
    console.log('I am generate RCV ');
    this.error = false;
    this.success = false;
    if (this.fields.cdkValue) {
      if(/^[0-9,]+$/i.test(this.fields.cdkValue)) {
        console.log('this.fields.cdkValue: ' + this.fields.cdkValue + ' --> '+ this.fields.selectedLetterKey + ' '+ this.fields.selectedAuditLevel);
        if(this.fields.selectedLetterKey == '?') {
          this.error = true;
          this.errorMessage ='Please Select Letter Type Key!';
          return false;
        } else if(this.fields.selectedAuditLevel == '?') {
          this.error = true;
          this.errorMessage ='Please Select Audit Level!';
          return false;
        }  else if(this.fields.selectedScanPrintCode == '?') {
          this.error = true;
          this.errorMessage ='Please Select Scan Print Code!';
          return false;
        } 
        // console.log('this.fields.cdkValue: ' + this.fields.cdkValue + 'About to call generatet RCV');
        this.generate();
      } else {
        this.error = true;
        this.errorMessage ='Accept CDK values with comma separated only(Numeric)!';
      }
    } else {
      this.error = true;
      this.errorMessage ='Please enter CDK values';
    }
  }

  generate() {
    this.btnText = 'Generating...';
    if(this.fields.cdkValue.substr(this.fields.cdkValue.length - 1) === ',') {
      this.fields.cdkValue = this.fields.cdkValue.slice(0, -1);
    }
    console.log('this.fields.cdkValue: ', this.fields.cdkValue)
    this.mainService.generateRCV(this.fields).subscribe(result => {
      this.btnText = 'Generate RCV';
      this.data = result[0];
      if (this.data.responseCode === 1 ) {
        this.success = true;
        this.successMessage = this.data.responseMessage;
        this.fields.cdkValue = '';
      } else {
        this.error = true;
        this.errorMessage = this.data.responseMessage;
      }
      // console.log('After Save CDK ', this.data);
    }, (error: any) => {
      this.btnText = 'Generate RCV';
      this.error = true;
      this.errorMessage = 'Internal Server Erorr...';
      // console.log('Saving CDK Error ', error);
      this.fields.cdkValue = '';
    });
  }

  restCDK() {
    this.fields.cdkValue = '';
  }

  executeCatAgent() {
    this.error = false;
    this.success = false;
    this.runningCAT = true;
    // this.runBtnText = 'Running...';
    this.mainService.executeCatAgent().subscribe(result => {
      console.log('After Executing cat agent: ', result);
      this.runningCAT = false;
      // this.runBtnText = 'Run';
      if (result == "1") {
        this.success = true;
        this.successMessage = "CAT Agent ran successfully..";
      } else {
        this.error = true;
        this.errorMessage = result;
      }
    }, (error: any) => {
      this.runningCAT = false;
      // this.runBtnText = 'Run';
      this.error = true;
      this.errorMessage = 'Not able to connect to server/ Internal server issue....';
      console.log('Error in Executing cat agent: ', error);
    });
  }

  getLetterKeys() {
    this.mainService.getLetterKeys().subscribe(result => {
      this.letterKeyData = result;
    }, (error: any) => {
      console.log('Error in Executing getLetterKeys: ', error);
    });
  }

  onChange(selected: any) {
    console.log('Selected element is' , selected, ' --> ', this.fields.selectedLetterKey);
  }
  ngOnInit() {
    this.getLetterKeys();
  }

}

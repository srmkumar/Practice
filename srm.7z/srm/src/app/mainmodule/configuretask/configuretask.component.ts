import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuretask',
  templateUrl: './configuretask.component.html',
  styleUrls: ['./configuretask.component.css']
})
export class ConfiguretaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfiguretaskComponent } from './configuretask.component';

describe('ConfiguretaskComponent', () => {
  let component: ConfiguretaskComponent;
  let fixture: ComponentFixture<ConfiguretaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfiguretaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfiguretaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

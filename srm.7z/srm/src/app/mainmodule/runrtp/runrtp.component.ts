import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-runrtp',
  templateUrl: './runrtp.component.html',
  styleUrls: ['./runrtp.component.css']
})
export class RunrtpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

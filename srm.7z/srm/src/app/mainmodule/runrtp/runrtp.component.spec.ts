import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RunrtpComponent } from './runrtp.component';

describe('RunrtpComponent', () => {
  let component: RunrtpComponent;
  let fixture: ComponentFixture<RunrtpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RunrtpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RunrtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

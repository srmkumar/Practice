import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CatagentComponent } from './catagent/catagent.component';
import { ConfiguretaskComponent } from './configuretask/configuretask.component';
import { GeneratercvComponent } from './generatercv/generatercv.component';
import { RollbackdevComponent } from './rollbackdev/rollbackdev.component';
import { RollbackqaComponent } from './rollbackqa/rollbackqa.component';
import { RunrtpComponent } from './runrtp/runrtp.component';
import { WipeoutComponent } from './wipeout/wipeout.component';
import { MainRoutingModule } from './main-routing.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    CatagentComponent, 
    ConfiguretaskComponent,
    GeneratercvComponent, 
    RollbackdevComponent, 
    RollbackqaComponent, 
    RunrtpComponent, 
    WipeoutComponent
  ],
  imports: [
    CommonModule,
    MainRoutingModule,
    FormsModule
  ]
})
export class MainmoduleModule { }

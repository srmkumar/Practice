import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';

@Component({
  selector: 'app-rollbackqa',
  templateUrl: './rollbackqa.component.html',
  styleUrls: ['./rollbackqa.component.css']
})
export class RollbackqaComponent implements OnInit {
  cdkValue: any;
  error = false;
  success = false;
  btnText = 'RollBack Claim';
  isrollBack: boolean = false;
  errorMessage = '';
  successMessage = '';
  data: any;
  constructor(private mainService: MainService) { }

  ngOnInit() {
  }

  rollBack() {
    console.log('RollBack Claim.....');
    this.error = false;
    this.success = false;
    if (this.cdkValue) {
      if(/^[0-9,]+$/i.test(this.cdkValue)) {
        this.rollBackClaim();
      } else {
        this.error = true;
        this.errorMessage ='Accept CDK value Numerics only!';
      }
    } else {
      this.error = true;
      this.errorMessage ='Please enter CDK values';
    }
  }

  rollBackClaim (){
    this.isrollBack = true;
    console.log('this.cdkValue: ', this.cdkValue)
    this.mainService.rollBackClaim(this.cdkValue).subscribe(result => {
      this.isrollBack = false;
      this.data = result[0];
      if (this.data.responseCode === 1 ) {
        this.success = true;
        this.successMessage = this.data.responseMessage;
        this.cdkValue = '';
      } else {
        this.error = true;
        this.errorMessage = this.data.responseMessage;
      }
    }, (error: any) => {
      this.isrollBack = false;
      this.error = true;
      this.errorMessage = 'Internal Server Erorr...';
      this.cdkValue = '';
    });
  }

}

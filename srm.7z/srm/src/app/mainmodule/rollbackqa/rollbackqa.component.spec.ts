import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RollbackqaComponent } from './rollbackqa.component';

describe('RollbackqaComponent', () => {
  let component: RollbackqaComponent;
  let fixture: ComponentFixture<RollbackqaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RollbackqaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RollbackqaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

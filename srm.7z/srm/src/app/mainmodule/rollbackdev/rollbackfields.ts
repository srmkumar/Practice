export class Rollbackfields {
    cdkValue: any = '';
    selectedTask: any = '?';
    selectedAuditLevel = '1';
    selectedAuditPassKey = '1';
}

import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Rollbackfields } from './Rollbackfields';

@Component({
  selector: 'app-rollbackdev',
  templateUrl: './rollbackdev.component.html',
  styleUrls: ['./rollbackdev.component.css']
})
export class RollbackdevComponent implements OnInit {
  error = false;
  success = false;
  btnText = 'RollBack Claim';
  isrollBack: boolean = false;
  errorMessage = '';
  successMessage = '';
  data: any;
  tasksData: any;
  constructor(private mainService: MainService,
    public fields: Rollbackfields) { }

  ngOnInit() {
  }

  getTasks() {
    console.log('this.fields.cdkValue: ', this.fields.cdkValue);
    if(this.fields.cdkValue) {
      this.mainService.getTasks(this.fields.cdkValue).subscribe(result => {
        this.tasksData = result;
      }, (error: any) => {
        console.log('Error in Executing getLetterKeys: ', error);
      }); 
    }
  }

  rollBack() {
    console.log('CDK Value', this.fields.cdkValue, ' selectedTask ' , this.fields.selectedTask , ' selectedTask ', this.fields.selectedAuditLevel);
    this.error = false;
    this.success = false;
    if (this.fields.cdkValue) {
      if(/^[0-9,]+$/i.test(this.fields.cdkValue)) {
        if(this.fields.selectedTask == '?') {
          this.error = true;
          this.errorMessage ='Please Select Letter Type Key!';
          return false;
        }/*  else if(this.fields.selectedAuditLevel == '?') {
          this.error = true;
          this.errorMessage ='Please Select Audit Level!';
          return false;
        } else if(this.fields.selectedAuditPassKey == '?') {
          this.error = true;
          this.errorMessage ='Please Select Audit Pass Key!';
          return false;
        } */

        this.fields.selectedAuditLevel = '1';
        this.fields.selectedAuditPassKey == '1';
        this.rollBackClaim();
      } else {
        this.error = true;
        this.errorMessage ='Accept CDK value Numerics only!';
      }
    } else {
      this.error = true;
      this.errorMessage ='Please enter CDK values';
    }
  }

  rollBackClaim (){
    this.isrollBack = true;
    this.mainService.rollBackClaim(this.fields).subscribe(result => {
      this.isrollBack = false;
      this.data = result[0];
      if (this.data.responseCode === 1 ) {
        this.success = true;
        this.successMessage = this.data.responseMessage;
        this.resetColumns();
      } else if (this.data.responseCode === 10 ) {
        this.error = true;
        this.errorMessage = this.data.responseMessage;
      } else {
        this.error = true;
        this.errorMessage = this.data.responseMessage;
      }
    }, (error: any) => {
      this.isrollBack = false;
      this.error = true;
      this.errorMessage = 'Internal Server Erorr...';
      this.resetColumns();
    });
  }

  resetColumns() {
    this.fields.cdkValue = '';
    this.fields.selectedTask = '?';
    this.fields.selectedAuditLevel = '1';
    this.fields.selectedAuditPassKey = '1';
  }
}

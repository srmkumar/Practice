import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RollbackdevComponent } from './rollbackdev.component';

describe('RollbackdevComponent', () => {
  let component: RollbackdevComponent;
  let fixture: ComponentFixture<RollbackdevComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RollbackdevComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RollbackdevComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

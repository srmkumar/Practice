import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';

@Component({
  selector: 'app-wipeout',
  templateUrl: './wipeout.component.html',
  styleUrls: ['./wipeout.component.css']
})
export class WipeoutComponent implements OnInit {

  txStramKey: any = '';
  btnText = 'Wipeout';
  error = false;
  success = false;
  errorMessage = '';
  successMessage = '';
  isWipeOut: boolean = false;
  data: any;
  constructor(private mainService: MainService) { }

  ngOnInit() {
  }

  wipeOut() {
    console.log('In wipeout script txStramKey: ', this.txStramKey);
    this.isWipeOut = true;
    this.btnText = 'Wipeing';
    this.error = false;
    this.success = false;
    if (this.txStramKey) {
      if(/^[0-9,]+$/i.test(this.txStramKey)) {
        this.wipe();
      } else {
        this.error = true;
        this.errorMessage ='Accept TxStream Key value Numerics only!';
      }
    } else {
      this.error = true;
      this.errorMessage ='Please enter TxStream Key values';
    }
    this.isWipeOut = false;
    this.btnText = 'Wipeout';
  }

  wipe() {
    this.btnText = 'Wipeing';
   
    console.log('this.txStramKey: ', this.txStramKey)
    this.mainService.wipeOut(this.txStramKey).subscribe(result => {
      this.btnText = 'Wipeout';
      this.data = result[0];
      if (this.data.responseCode === 1 ) {
        this.success = true;
        this.successMessage = this.data.responseMessage;
        this.txStramKey = '';
      } else {
        this.error = true;
        this.errorMessage = this.data.responseMessage;
      }
    }, (error: any) => {
      this.btnText = 'Wipeout';
      this.error = true;
      this.errorMessage = 'Internal Server Erorr...';
      this.txStramKey = '';
    });
  }

}

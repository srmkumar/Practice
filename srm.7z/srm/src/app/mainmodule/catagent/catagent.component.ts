import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catagent',
  templateUrl: './catagent.component.html',
  styleUrls: ['./catagent.component.css']
})
export class CatagentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

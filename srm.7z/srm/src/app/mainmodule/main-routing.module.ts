import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GeneratercvComponent } from './generatercv/generatercv.component';
import { RollbackqaComponent } from './rollbackqa/rollbackqa.component';
import { RollbackdevComponent } from './rollbackdev/rollbackdev.component';
import { CatagentComponent } from './catagent/catagent.component';
import { WipeoutComponent } from './wipeout/wipeout.component';
import { ConfiguretaskComponent } from './configuretask/configuretask.component';
import { RunrtpComponent } from './runrtp/runrtp.component';

export const routes: Routes = [
  { path: '', component: GeneratercvComponent },
  { path: 'rollback/qa', component: RollbackqaComponent },
  { path: 'rollback/dev', component: RollbackdevComponent },
  { path: 'catagent', component: CatagentComponent },
  { path: 'wipeout', component: WipeoutComponent },
  /* { path: 'configuretask', component: ConfiguretaskComponent }, */
  { path: 'runrtp', component: RunrtpComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainRoutingModule { }

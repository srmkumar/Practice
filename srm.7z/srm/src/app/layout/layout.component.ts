import { Component, OnInit } from '@angular/core';
import { MainService } from '../mainmodule/main.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  public toggleBarIcon:boolean=true;
  isDev: boolean = false;
  isQA: boolean = false;
  constructor(private mainService: MainService) {
    if(mainService.isDev) {
      this.isDev = true;
    } else if(mainService.isQA) {
      this.isQA = true;
    }
  }

  ngOnInit() {
  }

  toggle(): void {
    let self = this;
    setTimeout(() => {
      self.toggleBarIcon = !self.toggleBarIcon;
    }, 500)
  }

}

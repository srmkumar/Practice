import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutComponent } from './layout/layout.component';
import { Ng2AutoBreadCrumb } from "ng2-auto-breadcrumb";
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { GenerateFields } from './mainmodule/generatercv/GenerateFields';
import { Rollbackfields } from './mainmodule/rollbackdev/Rollbackfields';

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    Ng2AutoBreadCrumb,
    RouterModule,
    FormsModule,
    HttpClientModule,
    HttpModule,
  ],
  providers: [GenerateFields, Rollbackfields],
  bootstrap: [AppComponent]
})
export class AppModule { }

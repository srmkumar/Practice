import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';

export const routes: Routes = [
  { path: '', redirectTo: 'a/astep', pathMatch: 'full', },
  { path: 'a', redirectTo: 'a/astep', pathMatch: 'full', },
  {
    path: 'a',
    component: LayoutComponent,
    children: [
      { path: 'astep',  loadChildren: './mainmodule/mainmodule.module#MainmoduleModule' },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './authentication/login/login.component';
import { CommonModule } from '@angular/common';
import { InboxComponent } from './dashboard/inbox/inbox.component';
import { LookupComponent } from './dashboard/lookup/lookup.component';
import { HeaderComponent } from './dashboard/header/header.component';
import { AuditviewComponent } from './dashboard/auditview/auditview.component';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'audit', component: HeaderComponent,
    children: [
      { path: 'inbox', component: InboxComponent },
      { path: 'lookup', component: LookupComponent },
      { path: 'auditview/:id', component: AuditviewComponent },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes), CommonModule
  ],
  declarations: []
})
export class AppRoutingModule { }
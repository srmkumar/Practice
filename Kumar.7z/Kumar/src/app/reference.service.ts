import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ReferenceService {

  constructor(private router: Router) { }

  navigatePath(path: any) {
    console.log('Path is : ', path)
    this.router.navigate([path]);
  }

}

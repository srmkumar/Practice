import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxLoadingModule } from 'ngx-loading';
import { RouterPaths } from './router-paths';
import { HeaderComponent } from '../dashboard/header/header.component';
import { LookupComponent } from '../dashboard/lookup/lookup.component';
import { InboxComponent } from '../dashboard/inbox/inbox.component';
import { AuditviewComponent } from '../dashboard/auditview/auditview.component';
import { AccordionModule } from '@syncfusion/ej2-angular-navigations';
import { Ng2FlatpickrModule } from 'ng2-flatpickr';

@NgModule({
  declarations: [HeaderComponent,
    LookupComponent,
    InboxComponent,
    AuditviewComponent],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AccordionModule,
    Ng2FlatpickrModule,
    NgxLoadingModule.forRoot({})
  ],
  exports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AccordionModule,
    Ng2FlatpickrModule,
    NgxLoadingModule
  ],

  providers: [
    RouterPaths,
  ]
})
export class SharedModule { }

export class RouterPaths {
    login = 'login';
    dashboard = '/audit/dashboard';
    audit_view = '/audit/auditview';
}

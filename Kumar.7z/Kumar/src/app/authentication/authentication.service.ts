import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  apiUrl: any = environment.apiURL; // Main server URL
  accessToken: any; // To hold accessToken
  refreshToken: any; // To hold refreshToken
  headers: HttpHeaders;

  constructor(private httpClient: HttpClient) {
  
  }

  login(body: any) {

  }
 
}

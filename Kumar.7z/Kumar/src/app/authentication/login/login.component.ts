import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService } from '../authentication.service';
import { ActivatedRoute } from '@angular/router';
import { RouterPaths } from 'src/app/shared/router-paths';
import { ReferenceService } from 'src/app/reference.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup; // To maintaing UserName and Passsword
  localStorage: any; // To access or set local session
  loading = false; // Loading enable or disable
  submitted = false;

  constructor(private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private route: ActivatedRoute,
    private routerPaths: RouterPaths,
    private referenceService: ReferenceService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get form() { return this.loginForm.controls; }
  eventHandler(keyCode: any) { if (keyCode === 13) { this.login(); } }

  public login() {
    this.loading = true;
    console.log('this.loginForm.invalid: ', this.loginForm.invalid);
    this.referenceService.navigatePath('audit/inbox');
    /* if (this.loginForm.invalid) {
      return;
    }
     try {
      if (!this.form.userName.value || !this.form.password.value) {
        this.loading = false;
        console.log('Username or password can\'t be empty!');
      } else {
        this.referenceService.navigatePath('logon');
        // Login Logic
      }
    } catch (error) {
    } */
  }
}

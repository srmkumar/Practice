import { Component, OnInit, DoCheck } from '@angular/core';
import { ReferenceService } from 'src/app/reference.service';
import { Location } from '@angular/common';
import { DashboardService } from '../dashboard.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, DoCheck  {
  location: Location;
  constructor(public referenceService: ReferenceService,
    location: Location,
    public dashboardService: DashboardService) {
    this.updateMenu(location);
  }

  updateMenu(location: Location) {
    this.location = location;
    const url = this.location.path();
    if (url.indexOf("audit/inbox") >= 0) {
      this.dashboardService.baseRoute = 'inbox';
    } if (url.indexOf("audit/lookup") >= 0) {
      this.dashboardService.baseRoute = 'lookup';
    }
  }

  ngOnInit() {
  }

  ngDoCheck() {
    this.updateMenu(this.location);
  }

}

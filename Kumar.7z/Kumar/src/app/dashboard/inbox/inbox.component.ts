import { Component, ViewChild, OnInit } from '@angular/core';
import { ReferenceService } from 'src/app/reference.service';

declare var $;
@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.css']
})
export class InboxComponent implements OnInit {

  @ViewChild('dataTable') table;
  dataTable: any;

  constructor(public referenceService: ReferenceService) { }

  ngOnInit() {
    this.dataTable = $(this.table.nativeElement);
    this.dataTable.DataTable({
      "bPaginate": false,
      "bLengthChange": false,
      "bFilter": true,
      "bInfo": false,
      "scrollX": true,
      "searching": false,
      "hover": true });
  }
}

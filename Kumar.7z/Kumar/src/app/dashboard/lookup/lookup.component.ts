import { Component, OnInit } from '@angular/core';
import flatpickr from 'flatpickr';

declare var $;
@Component({
  selector: 'app-lookup',
  templateUrl: './lookup.component.html',
  styleUrls: ['./lookup.component.css']
})
export class LookupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    flatpickr('.flatpickr', {
      dateFormat: 'j/m/Y',
      time_24hr: false
    });
  }

}

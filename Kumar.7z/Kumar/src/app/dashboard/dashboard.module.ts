import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { LookupComponent } from './lookup/lookup.component';
import { InboxComponent } from './inbox/inbox.component';
import { AuditviewComponent } from './auditview/auditview.component';

@NgModule({
  declarations: [HeaderComponent, LookupComponent, InboxComponent, AuditviewComponent],
  imports: [
    CommonModule
  ]
})
export class DashboardModule { }
